import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [num1, setFirstNum] = useState('');
  const [num2, setSecondNum] = useState('');
  const [operation, setOperation] = useState(null);
  const [result, setResult] = useState('');

  const calculate = () => {
    const num1 = parseFloat(document.getElementById('first').value);
    const num2 = parseFloat(document.getElementById('second').value);

    if (isNaN(num1) || isNaN(num2)) return;

    let result;
    switch(operation) {
      case '+':
        result = num1 + num2;
        break;
      case '-':
        result = num1 - num2;
        break;
      case '*':
        result = num1 * num2;
        break;
      case '/':
        if (num2 !== 0) {
          result = num1 / num2;
        } else {
          alert("Cannot divide by zero!");
          return;
        }
        break;
    }

    // Limit to 2 decimal places
    result = parseFloat(result.toFixed(2));

    setResult(result.toString());
    setFirstNum('');
    setSecondNum('');
    setOperation(null);
  }

  const handleOperation = (op) => {
    if (num1 === '') {
      setOperation(op);
    } else {
      calculate();
      setOperation(op);
    }
  }

  return (
    <>
      <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React Calculator</h1>
      <div className="card">
        <input type='number' placeholder='First Number' id='first' value={num1} onChange={(e) => setFirstNum(e.target.value)} />
        <button onClick={() => handleOperation('+')} id='add'>+</button>
        <button onClick={() => handleOperation('-')} id='sub'>-</button>
        <button onClick={() => handleOperation('*')} id='times'>*</button>
        <button onClick={() => handleOperation('/')} id='divide'>/</button>
        <input type='number' placeholder='Second Number' id='second' value={num2} onChange={(e) => setSecondNum(e.target.value)} />
        <button onClick={calculate} id='equals'>=</button>
        <button onClick={() => {setFirstNum(''); setSecondNum(''); setOperation(null);}} id='clear'>Clear</button>

        <p>Result: {result}</p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  )
}

export default App
